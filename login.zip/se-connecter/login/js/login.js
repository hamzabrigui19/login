$(document).ready(function() {
    $("#logform").submit(function() {
        return false;
    });
});